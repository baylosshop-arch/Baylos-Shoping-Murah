BAYLOS SHOPING MURAH - FINAL PROJECT

File:
1. index.html  = tampilan toko asli user, dipertahankan; Supabase + analytics + theme settings dihubungkan.
2. admin.html  = Admin Pro: login Supabase, CRUD produk, upload gambar, theme studio, logout.
3. config.js   = koneksi Supabase frontend (anon key saja).
4. supabase.sql = tabel + kolom analytics + RLS non-destruktif.

Supabase project:
https://emviceyluewhfwckuntj.supabase.co

PENTING:
- Jangan masukkan service_role key ke GitHub.
- Jalankan supabase.sql di Supabase SQL Editor.
- Buat Storage bucket bernama product-images dan set Public.
- Buat 1 user admin di Authentication > Users.
- Upload ke repository GitHub Pages pada folder yang sama: index.html, admin.html, config.js.
- Jika GitHub Pages memakai root, buka index.html dari URL Pages. Tombol ⚙ membuka admin.html.
