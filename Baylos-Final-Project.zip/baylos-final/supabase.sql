-- BAYLOS FINAL DATABASE SETUP
create extension if not exists pgcrypto;

create table if not exists public.products (
    id uuid primary key default gen_random_uuid(),
    name text not null,
    category text default 'Lainnya',
    price numeric default 0,
    label text default '',
    affiliate_url text default '',
    image_url text default '',
    description text default '',
    sort_order integer default 0,
    is_active boolean default true,
    created_at timestamptz default now()
);

create table if not exists public.store_settings (
    id integer primary key,
    primary_color text default '#172033',
    accent_color text default '#c9a45c',
    background_color text default '#f7f5f1',
    border_color text default '#e8e2d8',
    desktop_columns integer default 4,
    card_radius integer default 22,
    product_gap integer default 18,
    hero_image_url text default '',
    hero_label text default 'BAYLOS SHOPING MURAH',
    hero_title text default 'Fashion Cantik. Harga Bersahabat.',
    hero_description text default 'Temukan produk pilihan Baylos dengan harga menarik.',
    updated_at timestamptz default now()
);

insert into public.store_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.analytics_events (
    id bigint generated always as identity primary key,
    session_id text not null,
    event_type text not null,
    product_id uuid null,
    product_name text null,
    page text default 'home',
    source text,
    referrer text,
    device text,
    created_at timestamptz default now()
);

alter table public.analytics_events add column if not exists source text;
alter table public.analytics_events add column if not exists referrer text;
alter table public.analytics_events add column if not exists device text;

create index if not exists idx_products_active on public.products(is_active);
create index if not exists idx_products_category on public.products(category);
create index if not exists idx_products_created on public.products(created_at desc);
create index if not exists idx_analytics_created on public.analytics_events(created_at desc);
create index if not exists idx_analytics_type on public.analytics_events(event_type);
create index if not exists idx_analytics_product on public.analytics_events(product_id);

alter table public.products enable row level security;
alter table public.store_settings enable row level security;
alter table public.analytics_events enable row level security;

-- Safe non-destructive policies: only create if absent.
do $$
begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='products' and policyname='Public can read active products') then
    create policy "Public can read active products" on public.products for select to anon, authenticated using (is_active = true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='products' and policyname='Authenticated manage products') then
    create policy "Authenticated manage products" on public.products for all to authenticated using (true) with check (true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='store_settings' and policyname='Public can read store settings') then
    create policy "Public can read store settings" on public.store_settings for select to anon, authenticated using (true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='store_settings' and policyname='Authenticated manage store settings') then
    create policy "Authenticated manage store settings" on public.store_settings for all to authenticated using (true) with check (true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='analytics_events' and policyname='Public can insert analytics') then
    create policy "Public can insert analytics" on public.analytics_events for insert to anon, authenticated with check (true);
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='analytics_events' and policyname='Authenticated can read analytics') then
    create policy "Authenticated can read analytics" on public.analytics_events for select to authenticated using (true);
  end if;
end $$;

-- Storage bucket must be created from Dashboard if it does not exist:
-- Storage > New bucket > product-images > Public bucket.
